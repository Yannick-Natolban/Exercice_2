package gestion_atelier_db.services;

import gestion_atelier_db.entities.Categorie;

public interface CategorieService extends IService<Categorie> {
    
}
